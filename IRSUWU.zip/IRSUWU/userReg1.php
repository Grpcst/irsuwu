<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Admin Page</title>


    <!-- Bootstrap -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="bootstrap/css/animate-custom.css" rel="stylesheet">
    <link href="bootstrap/css/bootstrap.css" rel="stylesheet">
    <link href="bootstrap/css/bootstrap-theme.css" rel="stylesheet">
    <link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet">
    <link href="bootstrap/css/style.css" rel="stylesheet">

    <link href="bootstrap/js/bootstrap.js" rel="stylesheet">
    <link href="bootstrap/js/bootstrap.min.js" rel="stylesheet">
    <link href="bootstrap/js/npm.js" rel="stylesheet">

	   <link rel = "stylesheet" type="text/css" href="style.css">

   
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

     <!--Adding favicon
     <link rel="icon" href="images/favicon.ico" type="favicon/ico">
     -->
     
  </head>

  <body>

  <div class="container-fluid">
     <div class = "row">

    <div class = "col-md-4">
        <img src="logo.jpg" id="logo">

        <h1 id = "h1"><b>IRS 2017</b></h1>
    </div>
          <br><br>
          <!--
        <div class="col-md-8"> 
          <div class = "col-md-4">
              <a href="userReg.php"><button id ="submitbtn">Add Users</button></a>          
          </div>
          <div class = "col-md-4">
              <a href="sub.php"><button id ="submitbtn">Abstracts</button></a>          
          </div>
        </div>
        -->
      <div class="dropdown">
        <button class="btn btn-primary dropdown-toggle" type="button1" data-toggle="dropdown">Users Management
        <span class="caret"></span></button>
        <ul class="dropdown-menu">
          <li><a href="userReg.php">Add</a></li>
          <li><a href="#">Remove</a></li>
          <li><a href="#">Recrute</a></li>
        </ul>
      </div>

<div class="btn-group">
  <button type="button" class="btn btn-primary">Abstacts</button>
  <button type="button" class="btn btn-primary dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="caret"></span>
  </button>
  <div class="dropdown-menu">
    <li><a href="admin_abs_cs.php">Computer Science</a></li>
    <li><a href="admin_abs_sct.php">Science and Technology</a></li>
    <li><a href="admin_abs_mgt.php">Management</a></li>
    <li><a href="admin_abs_ans.php">Animal Science</a></li>
    <li><a href="admin_abs_agri.php">Agriculture</a></li>
  </div>
</div>

<div class="btn-group">
  <button type="button" class="btn btn-primary">View Users</button>
  <button type="button" class="btn btn-primary dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="caret"></span>
  </button>
  <div class="dropdown-menu">
    <li><a href="#">Authors</a></li>
    <li><a href="#">Reviewers</a></li>
    <li><a href="#">Track Co-ordinators</a></li>
  </div>
</div>

    </div>
    <hr class="featurette-divider hidden-md">
        <div class="container">
        <div class="row">
            <div class="col-sm-8 col-sm-offset-2">
                <div class="page-header">
                    <h2>Registration Form</h2>
                </div>

                <form id="defaultForm" method="post" class="form-horizontal" action="reg_admin.php">

                    <div class="form-group">
                        <label class="col-md-3 control-label">Role</label>
                        <div class="col-md-6">
                            <select class="form-control" id="exampleSelect1" name="role">
                                <option>Select</option>
                                <option>Author</option>
                                <option>Track_Co-ordinator_cs</option>
                                <option>Track_Co-ordinator_sc</option>
                                <option>Track_Co-ordinator_ans</option>
                                <option>Track_Co-ordinator_agri</option>
                                <option>Track_Co-ordinator_mgt</option>
                                <option>reviewer_cs</option>
                                <option>reviewer_sct</option>
                                <option>reviewer_mgt</option>
                                <option>reviewer_ans</option>
                                <option>reviewer_agri</option>
                                <option>Admin</option>    
                            </select>
                        </div>
                    </div>  
                    
                    <div class="form-group">
                        <label class="col-md-3 control-label">First Name</label>
                        <div class="col-md-6">
                            <input type="text" class="form-control" placeholder="First Name" required name="fname"/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label">Last Name</label>
                        <div class="col-md-6">
                            <input type="text" class="form-control" placeholder="last Name" name="lname" required/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label">Organization</label>
                        <div class="col-md-6">
                            <input type="text" class="form-control" placeholder="Organization" name="orgname" required/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label">City</label>
                        <div class="col-md-6">
                            <select class="form-control" id="exampleSelect1" name="city" required>
                                <option>Select</option>
                                <option>Colombo</option>
                                <option>Kalutara</option>
                                <option>Gampaha</option>
                                <option>Galle</option>
                                <option>Matara</option> 
                                <option>Hambanthota</option>
                                <option>Kurunegala</option> 
                                <option>Puttlam</option>
                                <option>Kandy</option>
                                <option>Matale</option>
                                <option>Dambulla</option> 
                                <option>Nuwara Eliya</option>
                                <option>Badulla</option>
                                <option>Monaragala</option>  
                                <option>Trincomalie</option>
                                <option>Jaffna</option>
                                <option>Vavniya</option> 
                                <option>Anuradapura</option>
                                <option>Polonnaruwa</option> 
                                <option>Kegalle</option>
                                <option>Ratnapura</option>
                                <option>Chillaw</option>
                                <option>Ampata</option> 
                                <option>Baticaloa</option>
                                    
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label">Contact Number</label>
                        <div class="col-md-6">
                            <input type="text" class="form-control" placeholder="Contact Number" name="contact" required />
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label">E-mail</label>
                        <div class="col-md-6">
                            <input type="text" class="form-control" placeholder="E-mail here" name="email" required/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label">Password</label>
                        <div class="col-md-6">
                            <input type="Password" class="form-control" placeholder="Password here" name="pw" required/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label">Confirm Password</label>
                        <div class="col-md-6">
                            <input type="Password" class="form-control" placeholder="Confirm Password" name="pw2" required/>
                        </div>
                    </div>
                        <div class="form-group">
                            <div class="col-md-6 control-label">
                                <button type="submit" class="btn btn-warning" name="signup"  value="Sign up">Submit</button>
                                <button type="reset" class="btn btn-warning" name="clear"  value="Clear">Clear</button>
                            </div>
                        </div>
                    
                </form>
            </div>
        </div>
    </div>

     

      <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
      <!--Footer-->
      <div class="footer" id="footer1">
        <div class="col-md-4" id="cpy"> Copyright &copy by CST_Creations</div>

      </div>    

      <div class="col-md-8" id="footer2">
        <div>
          <div class = "col-md-2">
            <a href="home.html">
                Home
              </a>
          </div>  

           <div class = "col-md-2">
            <a href="keydates.html">
                Key Dates</a>
          </div>

          <div class = "col-md-2">
            <a href="aboutus.html">
                About Us
              </a>
          </div>  

          <div class = "col-md-2">
            <a href="contactus.html">
                Contact Us
              </a>
          </div>  
        </div>
        
      </div>  

  </body>
  
  </html>