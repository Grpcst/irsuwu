            <?php
        // 1. Enter Database details
        $dbhost = 'localhost';
        $dbuser = 'root';
        $dbpass = '';
        $dbname = 'irsuwu';

        // 2. Create a database connection
        $conn = mysqli_connect($dbhost,$dbuser,$dbpass);
        if (!$conn) {
            die("Database connection failed: " . mysqli_error());
        }

        // 3. Select a database to use 
        $db_select = mysqli_select_db($conn,$dbname);
        if (!$db_select) {
            die("Database selection failed: " . mysqli_error());
        }

        $query = mysqli_query($conn,"update abstract set status='sent' where abstractID='".$_GET["rid"]."'");
        header("location:trackco_agri.php");

      ?>