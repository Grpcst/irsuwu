<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>IRSUWU|2017</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/modern-business.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">


</head>

<body>
    <style>
    .navbar-inverse {
    background-color: #070B5F;
    border-color: #080808;
}
</style>

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">International Research Symposium|2017</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="active">
                        <a href="about.html">About</a>
                    </li>
                    <li>
                        <a href="contact.html">Contact</a>
                    </li>
                    <li class="dropdown-user">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">User Management<b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li><a href="userReg.php">Add</a></li>
                            <li><a href="#">Remove</a></li>
                            <li><a href="#">Recrute</a></li>
                        </ul>
                    </li>
                    <li class="dropdown-abs">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Abstract View<b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li><a href="admin_abs_cs.php">Computer Science</a></li>
                            <li><a href="admin_abs_sct.php">Science and Technology</a></li>
                            <li><a href="admin_abs_mgt.php">Management</a></li>
                            <li><a href="admin_abs_ans.php">Animal Science</a></li>
                            <li><a href="admin_abs_agri.php">Agriculture</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
    <!-- Page Content -->
    <div class="container">

        <!-- Page Heading/Breadcrumbs -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Admin Page
                    <small>IRSUWU|2017</small>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="index.html">Home</a>
                    </li>
                    <li class="active">Contact</li>
                </ol>
            </div>
        </div>
        <!-- /.row -->
    <div class="container">
        <div class="row">
            <div class="col-sm-8 col-sm-offset-2">
                <div class="page-header">
                    <h2>Registration Form</h2>
                </div>

                <form id="defaultForm" method="post" class="form-horizontal" action="reg_admin.php">

                    <div class="form-group">
                        <label class="col-md-3 control-label">Role</label>
                        <div class="col-md-6">
                            <select class="form-control" id="exampleSelect1" name="role">
                                <option>Select</option>
                                <option>Author</option>
                                <option>Track_Co-ordinator_cs</option>
                                <option>Track_Co-ordinator_sc</option>
                                <option>Track_Co-ordinator_ans</option>
                                <option>Track_Co-ordinator_agri</option>
                                <option>Track_Co-ordinator_mgt</option>
                                <option>reviewer_cs</option>
                                <option>reviewer_sct</option>
                                <option>reviewer_mgt</option>
                                <option>reviewer_ans</option>
                                <option>reviewer_agri</option>
                                <option>Admin</option>    
                            </select>
                        </div>
                    </div>  
                    
                    <div class="form-group">
                        <label class="col-md-3 control-label">First Name</label>
                        <div class="col-md-6">
                            <input type="text" class="form-control" placeholder="First Name" required name="fname"/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label">Last Name</label>
                        <div class="col-md-6">
                            <input type="text" class="form-control" placeholder="last Name" name="lname" required/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label">Organization</label>
                        <div class="col-md-6">
                            <input type="text" class="form-control" placeholder="Organization" name="orgname" required/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label">City</label>
                        <div class="col-md-6">
                            <select class="form-control" id="exampleSelect1" name="city" required>
                                <option>Select</option>
                                <option>Colombo</option>
                                <option>Kalutara</option>
                                <option>Gampaha</option>
                                <option>Galle</option>
                                <option>Matara</option> 
                                <option>Hambanthota</option>
                                <option>Kurunegala</option> 
                                <option>Puttlam</option>
                                <option>Kandy</option>
                                <option>Matale</option>
                                <option>Dambulla</option> 
                                <option>Nuwara Eliya</option>
                                <option>Badulla</option>
                                <option>Monaragala</option>  
                                <option>Trincomalie</option>
                                <option>Jaffna</option>
                                <option>Vavniya</option> 
                                <option>Anuradapura</option>
                                <option>Polonnaruwa</option> 
                                <option>Kegalle</option>
                                <option>Ratnapura</option>
                                <option>Chillaw</option>
                                <option>Ampata</option> 
                                <option>Baticaloa</option>
                                    
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label">Contact Number</label>
                        <div class="col-md-6">
                            <input type="text" class="form-control" placeholder="Contact Number" name="contact" required />
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label">E-mail</label>
                        <div class="col-md-6">
                            <input type="text" class="form-control" placeholder="E-mail here" name="email" required/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label">Password</label>
                        <div class="col-md-6">
                            <input type="Password" class="form-control" placeholder="Password here" name="pw" required/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label">Confirm Password</label>
                        <div class="col-md-6">
                            <input type="Password" class="form-control" placeholder="Confirm Password" name="pw2" required/>
                        </div>
                    </div>
                        <div class="form-group">
                            <div class="col-md-6 control-label">
                                <button type="submit" class="btn btn-warning" name="signup"  value="Sign up">Submit</button>
                                <button type="reset" class="btn btn-warning" name="clear"  value="Clear">Clear</button>
                            </div>
                        </div>
                    
                </form>
            </div>
        </div>
    </div>
   

        <hr>

        <!-- Footer -->
        <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p>Copyright &copy; Your Website 2014</p>
                </div>
            </div>
        </footer>

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Contact Form JavaScript -->
    <!-- Do not edit these files! In order to set the email address and subject line for the contact form go to the bin/contact_me.php file. -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>

</body>

</html>
