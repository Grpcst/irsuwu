<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>IRSUWU|2017</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/modern-business.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">


</head>

<body>
    <style>
    .navbar-inverse {
    background-color: #070B5F;
    border-color: #080808;
}
</style>

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">International Research Symposium|2017</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="active">
                        <a href="about.html">About</a>
                    </li>
                    <li>
                        <a href="contact.html">Contact</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
    <!-- Page Content -->
    <div class="container">

        <!-- Page Heading/Breadcrumbs -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Contact
                    <small>IRSUWU|2017</small>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="index.html">Home</a>
                    </li>
                    <li class="active">Contact</li>
                </ol>
            </div>
        </div>
        <!-- /.row -->
        <div class="container">
        <div class="row">
            <div class="col-sm-8 col-sm-offset-2">
                <div class="page-header">
                    <h2>Abstract Submissions</h2>
                </div>

                <form id="defaultForm" method="post" class="form-horizontal" action="submit.php" enctype="multipart/form-data">
                    
                    <div class="form-group">
                        <label class="col-md-2 control-label">Title</label>
                        <div class="col-md-10">
                            <input type="text" id="title" class="form-control" name="title" required="true"/>
                        </div>
                    </div>

                    <div class="form-group">
                         <label class="col-md-2 control-label">Abstract</label>
                         <div class="col-md-10">
                                    <textarea class="form-control" id="abstract" rows="15" required="true" name="abstract"></textarea>  
                                   <!-- <?php
                                        $words = $_POST['abstract'];
                                        $count = str_word_count($_POST['abstract']);
                                        //echo str_word_count("Hello world!");

                                        //$var =textareaObject.value ; //Store textarea text in $var 
                                        //print_r(str_word_count($var));
                                        //$words= str_word_count($_POST['clientdetails']);

                                        if ($count < 450) {
                                            $remain = 450 - $count;
                                            echo "($remain) words";
                                        } else {
                                            echo "($remain) words You have exceed the word limit";
                                        }
                                        
                                    ?>      -->         
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-2 control-label">Author(s)</label>
                        <div class="col-md-10">
                            <textarea class="form-control" id="authors" rows="3" name="authors"></textarea>
                           
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-2 control-label">Keywords</label>
                        <div class="col-md-10">
                            <input type="text" id="keywords" class="form-control" name="keyword" required="true"/>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="col-md-2 control-label">Track</label>
                        <div class="col-md-10">
                            <select class="form-control" id="exampleSelect1" name="track">
                                <option>Select</option>
                                <option value='1'>Computer Science</option>
                                <option value='2'>Science and Technology</option>
                                <option value='3'>Mangement</option>
                                <option value='4'>Animal Science</option>
                                <option value='5'>Agriculture</option>  
                            </select>
                        </div>
                    </div>      
                    
                    <div class="form-group">
                        <label class="col-md-2 control-label">Presentation Type</label>
                        <div class="col-md-10" name="ppttype">
                            <div class="radio">
                                <label>
                                    <input type="radio" id="oral" name="presentation" value="oral" /> Oral
                                </label>
                            </div>
                            <div class="radio">
                                <label>
                                    <input type="radio" id="poster" name="presentation" value="pposter" /> Poster
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="col-md-2 control-label">Upload your PDF file</label>
                            <div class="col-md-10">
                                <input type="file" class="form-control-file" id="exampleInputFile" aria-describedby="fileHelp" required="true" name="pdf">      
                            </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="col-md-6 control-label">
                            <div class="checkbox">
                                <label>
                                    <input type="checkbox" name="agree" value="agree" /> I agree to <a href="terms.php">Terms and Conditions</a> 
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="col-md-4 control-label">
                            <button type="submit" class="btn btn-warning" name="signup" id="btnsubmit"  value="Sign up">Submit</button>
                            <button type="reset" class="btn btn-warning" name="clear"  id="btnclear" value="Sign up">Clear</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
        <hr>

        <!-- Footer -->
        <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p>Copyright &copy; Your Website 2014</p>
                </div>
            </div>
        </footer>

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Contact Form JavaScript -->
    <!-- Do not edit these files! In order to set the email address and subject line for the contact form go to the bin/contact_me.php file. -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>

</body>

</html>
