<?php

 require('dbconnect.php');

 $role=$_POST['role'];
 $userID=$_POST['userID'];
 $fname=$_POST['fname'];
 $lname=$_POST['lname'];
 $orgname=$_POST['orgname'];
 $city=$_POST['city'];
 $contact=$_POST['contact'];
 $email=$_POST['email'];
 $pw=$_POST['pw'];

//set the random id length 
$random_id_length = 3; 

//generate a random id encrypt it and store it in $userID 
$userID = crypt(uniqid(rand(),1)); 

//to remove any slashes that might have come 
$userID = strip_tags(stripslashes($userID)); 

//Removing any . or / and reversing the string 
$userID = str_replace(".","",$userID); 
$userID = strrev(str_replace("/","",$userID)); 

//finally I take the first 10 characters from the $userID 
$userID = substr($userID,0,$random_id_length); 

//echo "Random Id: $userID" ;
//echo "<br>";

 $q=mysql_query("insert into register values('".$role."','".$userID."','".$fname."','".$lname."','".$orgname."','".$city."','".$contact."','".$email."','".$pw."')") or die(mysql_error());

 if ($q) {
header("location:admin.php"); }
?>