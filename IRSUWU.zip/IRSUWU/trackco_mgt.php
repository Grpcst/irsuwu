<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>IRSUWU|2017</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/modern-business.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">


</head>

<body>
    <style>
    .navbar-inverse {
    background-color: #070B5F;
    border-color: #080808;
}
</style>

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">International Research Symposium|2017</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="active">
                        <a href="about.html">About</a>
                    </li>
                    <li>
                        <a href="contact.html">Contact</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
    <!-- Page Content -->
    <div class="container">

        <!-- Page Heading/Breadcrumbs -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Track Co-ordination
                    <small>IRSUWU|2017</small>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="index.html">Home</a>
                    </li>
                    <li class="active">Management</li>
                </ol>
            </div>
        </div>
        <!-- /.row -->

        <!-- Content Row -->
        <?php
        // 1. Enter Database details
        $dbhost = 'localhost';
        $dbuser = 'root';
        $dbpass = '';
        $dbname = 'irsuwu';

        // 2. Create a database connection
        $conn = mysqli_connect($dbhost,$dbuser,$dbpass);
        if (!$conn) {
            die("Database connection failed: " . mysqli_error());
        }

        // 3. Select a database to use 
        $db_select = mysqli_select_db($conn,$dbname);
        if (!$db_select) {
            die("Database selection failed: " . mysqli_error());
        }

        $query = mysqli_query($conn,"SELECT * FROM abstract where track='3'");

      ?>

      
      <div class="container">
          <div class="table-responsive" >
          <table style="width:100%" border="1px" padding="1px" class="table table-hover">
            <thead style="background-color: darkblue; color: white;">
            
              <tr>
                <th>Author ID</th>
                <th>Abstract ID</th>
                <th>Title</th>
                <th>Submitted Date</th>
                <th>Modified Date</th>
                <th>Status</th>
                <th></th>
              </tr>
            </thead> 
          <?php

            while ($rows = mysqli_fetch_array($query)) {
               $userID = $rows['userID'];
               $abstractID = $rows['abstractID'];
               $title = $rows['title'];
               $submittedDate = $rows['submittedDate'];
               $modifiedDate = $rows['modifiedDate'];
               $status = $rows['status'];

              echo "<tr><td>".$userID."</td><td>".$abstractID."</td><td>".$title."</td><td>".$submittedDate."</td><td>".$modifiedDate."</td><td>".$status."</td><td><a href='review_mgt.php?rid=".$rows['abstractID']."'>Review</a></td></tr>";
             
    }

          ?>
             

          </div>
        </table>
      </div>
        
        <!-- /.row -->

        <hr>

        <!-- Footer -->
        <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p>Copyright &copy; Your Website 2014</p>
                </div>
            </div>
        </footer>

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Contact Form JavaScript -->
    <!-- Do not edit these files! In order to set the email address and subject line for the contact form go to the bin/contact_me.php file. -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>

</body>

</html>
