<?php
session_start();

$host="localhost"; // Host name 
$username="root"; // Mysql username 
$password=""; // Mysql password 
$db_name="irsuwu"; // Database name 
$tbl_name="register"; // Table name 

// Connect to server and select databse.
mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");

// username and password sent from form 
$email=$_POST['uname']; 
$pw=$_POST['pw']; 


// To protect MySQL injection (more detail about MySQL injection)
$email = stripslashes($email);
$pw = stripslashes($pw);
$email = mysql_real_escape_string($email);
$pw = mysql_real_escape_string($pw);

$sql="SELECT * FROM register WHERE email='$email' and pw='$pw'";
$result=mysql_query($sql);

//$id = mysqli_query($conn,"select userID from register where email='$email' and pw='$pw'");
// Mysql_num_row is counting table row
$count=mysql_num_rows($result);
// If result matched $uname and $pw, table row must be 1 row


if($count==1){
$result=mysql_fetch_array($result);
$role = $result['role'];

$_SESSION['uname'] = $email;

//page link on the basis of user role you can add more  condition on the basis of ur roles in db
	if($role =='Admin'){
	 	$link = 'admin.php';
	}

	elseif($role =='Author'){
		$link = 'author.php';

	}elseif($role =='Track_Co-ordinator_cs'){
	 	$link = 'trackco_cs.php';

	}elseif($role =='Track_Co-ordinator_sc'){
	 	$link = 'trackco_sc.php';

	}elseif($role =='Track_Co-ordinator_ans'){
	 	$link = 'trackco_ans.php';

	}elseif($role =='Track_Co-ordinator_agri'){
	 	$link = 'trackco_agri.php';

	}elseif($role =='Track_Co-ordinator_mgt'){
	 	$link = 'trackco_mgt.php';

	}elseif($role =='reviewer_cs'){
	 	$link = 'reviewer_cs.php';

	}elseif($role =='reviewer_sct'){
	 	$link = 'reviewer_sct.php';

	}elseif($role =='reviewer_mgt'){
	 	$link = 'reviewer_mgt.php';

	}elseif($role =='reviewer_ans'){
	 	$link = 'reviewer_ans.php';

	}elseif($role =='reviewer_agri'){
	 	$link = 'reviewer_agri.php';

	}elseif($role =='Secretary'){
 		$link = 'sub.php';
	}else
		echo "Wrong User...";

 }else
 	echo "Invalid User";
 
// session Register $uname, $pw and redirect to file "login_success.php"
$_session["uname"] = $uname;
$_session["pw"] = $pw;
$_session["role"] = $role;
header("Location: ".$link."");


//else {
//echo "Wrong Username or Password";
//}
?>